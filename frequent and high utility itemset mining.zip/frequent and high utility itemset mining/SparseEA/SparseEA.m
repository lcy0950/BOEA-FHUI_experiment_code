function [Population,save_obj,save_div] = SparseEA(maxItemSup,maxItemTWU,max_evaluations, N, D, M, DATA,Wght,PW,problems)

% Evolutionary algorithm for sparse multi-objective optimization problems
%------------------------------- Reference --------------------------------
% Y. Tian, X. Zhang, C. Wang, and Y. Jin, An evolutionary algorithm for
% large-scale sparse multi-objective optimization problems, IEEE
% Transactions on Evolutionary Computation, 2019.
%--------------------------------------------------------------------------

	encoding = 'binary'; % 
    lower = zeros(1,D);
    upper = ones(1,D);


    %% Population initialization
    % Calculate the fitness of each decision variable
    TDec    = [];
    TMask   = [];
    TempPop = [];
    Fitness = zeros(1,D);
    REAL    = ~strcmp(encoding,'binary'); 
    for i = 1 : 1+4*REAL
        if REAL
            Dec = unifrnd(repmat(lower,D,1),repmat(upper,D,1));
        else
            Dec = ones(D,D);
        end
        Mask       = eye(D);
		Population = Dec.*Mask;
        for i1=1:size(Population,1)
            Population(i1,D+1:D+M) = object_fun2(Population(i1,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU);  
        end
		
		TDec       = [TDec;Dec];
        TMask      = [TMask;Mask];
        TempPop    = [TempPop,Population];
		
		Population_objs = Population(:,end-M+1:end); 
		Population_cons = zeros(D,1);
        Fitness    = Fitness + NDSort([Population_objs,Population_cons],inf);
    end
    % Generate initial population
    if REAL
        Dec = unifrnd(repmat(lower,N,1),repmat(upper,N,1));
    else
        Dec = ones(N,D);
    end
    Mask = zeros(N,D);
    for i = 1 : N
        Mask(i,TournamentSelection(2,ceil(rand*D),Fitness)) = 1;
    end
	Population = Dec.*Mask;
	for i2=1:size(Population,1)
		Population(i2,D+1:D+M) = object_fun2(Population(i2,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU);        
    end
	%Population
    
	
    % [Population,Dec,Mask,FrontNo,CrowdDis] = EnvironmentalSelection([Population,TempPop],[Dec;TDec],[Mask;TMask],N);
    [Population,Dec,Mask,FrontNo,CrowdDis] = EnvironmentalSelection([Population;TempPop],[Dec;TDec],[Mask;TMask],N,M);
    
    %% Optimization    
	evaluated = 1;
    save_obj = []; % ÿһ����HV
    save_div = [];
    %while NotTermination(Population)
%     div_0 = diversity_cal(D+2,50,Population);
%     save_div = [save_div;div_0];
    
    global eval; 
    while eval <= max_evaluations
        MatingPool       = TournamentSelection(2,2*N,FrontNo,-CrowdDis);
        [OffDec,OffMask] = Operator(Dec(MatingPool,:),Mask(MatingPool,:),Fitness,REAL);
        % Offspring        = INDIVIDUAL(OffDec.*OffMask);
		Offspring = OffDec.*OffMask;
		for i3=1:size(Offspring,1)
			Offspring(i3,D+1:D+M) = object_fun2(Offspring(i3,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU);        
		end
		
        % [Population,Dec,Mask,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Offspring],[Dec;OffDec],[Mask;OffMask],N,M);
        [Population,Dec,Mask,FrontNo,CrowdDis] = EnvironmentalSelection([Population;Offspring],[Dec;OffDec],[Mask;OffMask],N,M);
%         if ff == 1
%             Population
%             ff = 0;
%         end
        %----------------------------------------------------------
       
        
        [~, last_generation_F1_index] = find(FrontNo == 1);     
        now_F1_indivs = Population(last_generation_F1_index,:);
        temp1 = zeros(size(now_F1_indivs,1),1) + eval;
        temp2 = [now_F1_indivs(:,(D+1):(D+M)),temp1];      
        temp3 = diversity_cal(D+2,50,Population);
        save_obj = [save_obj;temp2];    
        save_div = [save_div;temp3,eval];
        %------------------------------------------------------------------------------

        
    end
end