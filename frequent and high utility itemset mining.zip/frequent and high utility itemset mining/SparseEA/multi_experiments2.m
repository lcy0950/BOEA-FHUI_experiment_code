function f = multi_experiments2(dataset)

%dataset = 'mushroom'; 
%------------------------------------------------
DATA = importdata(['..\dataset\',dataset,'_left_1or0.txt']); 
Wght=importdata(['..\dataset\',dataset,'_right.txt']);    
PW = sum(diag(DATA'*Wght)); 

N = 50; % Population size
max_evaluations = 200*N; % maximum number of evaluations   
D = size(DATA,2); 
proC = 1;
proM = 1/D; 

problems = 'mySU'; 
M = 2;   % number of objectives

%------------------------------------------------------------------------

%��ʮ��ʵ��
times = 30;

A_HVs = zeros(times,1); 
save_objs = []; 

 %------------------------------------------------
    % 1.����ÿ��item��support
    item_support = sum(DATA);
    maxItemSup = max(item_support);
    % 2.����ÿ��item��TWUֵ
    item_TWU = zeros(1,D);
    for j = 1:D
        sum_TWU = 0;
        for i = 1:size(DATA,1)
            if DATA(i,j) == 1
                sum_TWU = sum_TWU + sum(Wght(i,:));
            end
        end
        item_TWU(1,j) = sum_TWU;
    end
    maxItemTWU = max(item_TWU);
%------------------------------------------------
global eval;    
for k = 1:times
    eval = 0;
    
    [Population,save_obj,save_div] = SparseEA(maxItemSup,maxItemTWU,max_evaluations, N, D, M, DATA,Wght,PW,problems);
    save(['.\Result\Objs\',dataset,'\',num2str(k,'%01d')], 'save_obj');
    save(['.\Result\Divs\',dataset,'\',num2str(k,'%01d')], 'save_div');
    
    PopObj = Population(:,D+1:D+M);
    NonDominated = NDSort(PopObj,1) == 1;
    fmax_use = 1; % 
    [Score,~] = HV(PopObj(NonDominated,:),fmax_use);
    A_HVs(k,1) = Score;
    save(['.\Result\HVs\',dataset,'\',num2str(k,'%01d')], 'Score');
    
    fprintf('%d \n',k)
end


fprintf('%d �ζ���ʵ���ƽ��HV = %f \n', times,mean(A_HVs));
end