multi_experiments2('pumsb')
multi_experiments2('uscensus10')
multi_experiments2('pamap10')



