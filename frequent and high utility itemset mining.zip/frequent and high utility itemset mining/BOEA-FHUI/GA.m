function Offspring = GA(Parent, can_appear_items,item_support,item_TWU)
    %item_support,item_TWU
    item_score = item_support+item_TWU;
    proC = 1;
    Parent1 = Parent(1:floor(end/2),:);
    Parent2 = Parent(floor(end/2)+1:floor(end/2)*2,:);
    [N,D]   = size(Parent1);

   %% Genetic operators for binary encoding
    % One point crossover
    k = repmat(1:D,N,1) > repmat(randi(D,N,1),1,D);
    k(repmat(rand(N,1)>proC,1,D)) = false; % proC is the probabilities of doing crossover
    Offspring1    = Parent1;
    Offspring2    = Parent2;
    Offspring1(k) = Parent2(k);
    Offspring2(k) = Parent1(k);
    Offspring     = [Offspring1;Offspring2];

    % �������(����,ÿ������������һ���ɱ����λ�÷�������)
    location_of_1 = find(can_appear_items==1);
    for i = 1:2*N
        location_of_1 = location_of_1(randperm(length(location_of_1)));
        choosed = location_of_1(1,1:2); % ÿ�������Ӧ�Ŀɱ���λ
        p = choosed(1,1);q = choosed(1,2);
        if Offspring(i,p)==0 && Offspring(i,q)==0
            if item_score(1,p)>item_score(1,q)
                Offspring(i,p) = 1;
            else
                Offspring(i,q) = 1;
            end
        elseif  Offspring(i,p)==1 && Offspring(i,q)==1
            if item_score(1,p)>item_score(1,q)
                Offspring(i,q) = 0;
            else
                Offspring(i,p) = 0;
            end
        else
            if rand()<0.5
                Offspring(i,p) = ~Offspring(i,p);
            else  
                Offspring(i,q) = ~Offspring(i,q);
            end
        end
    end
end




