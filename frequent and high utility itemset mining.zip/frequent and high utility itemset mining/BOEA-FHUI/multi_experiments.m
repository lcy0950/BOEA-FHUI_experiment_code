function[]=multi_experiments(dataname)%(dataname)

dataset = dataname;
%----------------------------------------------------------
%dataset = 'chess';
DATA = importdata(['..\dataset\',dataset,'_left_1or0.txt']); 
Wght=importdata(['..\dataset\',dataset,'_right.txt']);  
PW = sum(diag(DATA'*Wght)); 

N = 50; % population size
max_evaluations = 200*N; % maximum number of evaluations   

D = size(DATA,2); 

problems = 'mySU'; 
M = 2;   % number of objectives
times = 30; % number of independent experiments
%--------------------------------------------------------------------------
A_HVs = zeros(times,1); % Store HV of each independent experiment
save_objs = []; % Store obj values of each independent experiment

[maxItemSup,maxItemTWU,item_support,item_TWU] = ItemSupTWU(DATA,Wght,D);

global eval;
for k = 1:times    
    eval = 0;
    Population = InitStrategy(DATA,N,D,item_support,item_TWU);
    for i=1:N
        Population(i,D+1:D+M) = object_fun(Population(i,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU);        
    end    
    [Population,save_obj,save_can_appear_items_num,save_div] = NSGAII(maxItemSup,maxItemTWU,item_support,item_TWU,max_evaluations,Population, N, D, M, DATA,Wght,problems);
    
    save(['.\Result\can_appear_items_num\',dataset,'\',num2str(k,'%01d')], 'save_can_appear_items_num');
    save(['.\Result\Objs\',dataset,'\',num2str(k,'%01d')], 'save_obj');
	save(['.\Result\Divs\',dataset,'\',num2str(k,'%01d')], 'save_div');
    
    % �������һ����HV
    PopObj = Population(:,D+1:D+M);
    NonDominated = NDSort(PopObj,1) == 1;
    fmax_use = 1; % 
    [Score,~] = HV(PopObj(NonDominated,:),fmax_use);
    %fprintf('���һ����HV = %f \n', Score);
    A_HVs(k,1) = Score;  
    save(['.\Result\HVs\',dataset,'\',num2str(k,'%01d')], 'Score');
    fprintf('%d \n',k)
end
fprintf('%d �ζ���ʵ���ƽ��HV = %f \n', times,mean(A_HVs));
end