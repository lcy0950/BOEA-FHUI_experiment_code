function f = diversity_cal(L,N,P)
%N�Ǹ��������
    max_v = (L-2)*N*(N-1);
    div = 0;
    for i=1:N
        for j=1:N
            div = div + sum(abs(P(i,1:L-2)-P(j,1:L-2)));
        end
    end
    f = div/max_v; 
end