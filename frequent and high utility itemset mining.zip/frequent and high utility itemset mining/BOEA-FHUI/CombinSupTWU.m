function[combin_TWU,combin_support]=CombinSupTWU(combin_TWU,combin_support,can_appear_items,Wght,DATA,maxItemTWU,maxItemSup,D)
    one_idx = find(can_appear_items==1); 
    one_idx_size = size(one_idx,2);%��ȡ�еĳ���
    for i=1:one_idx_size
        for j=i+1:one_idx_size
            pos1 = one_idx(1,i);
            pos2 = one_idx(1,j);
            sum_TWU=0;
            sum_support=0;
            for k = 1:size(DATA,1) 
                if DATA(k,pos1)==1 && DATA(k,pos2)==1
                    sum_support = sum_support+1;
                    sum_TWU = sum_TWU + sum(Wght(k,:));
                end
            end
            combin_TWU(pos1,pos2)=sum_TWU/maxItemTWU;
            combin_TWU(pos2,pos1)=combin_TWU(pos1,pos2);
            combin_support(pos1,pos2)=sum_support/maxItemSup;
            combin_support(pos2,pos1)=combin_support(pos1,pos2);
        end
    end
end