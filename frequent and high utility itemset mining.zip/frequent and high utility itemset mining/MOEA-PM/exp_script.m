multi_experiments('chess');
multi_experiments('accident10');
multi_experiments('connect');
multi_experiments('mushroom');
multi_experiments('USCensus10');
multi_experiments('PAMAP10');
multi_experiments('Pumsb');