function [Population,save_obj,save_can_appear_items_num,save_div] = NSGAII(maxItemSup,maxItemTWU,max_evaluations,Population, N, D, M, DATA,Wght,PW,problems,proC, proM)
% N ����Ⱥ��С; D�Ǹ����ά��; M��Ŀ�꺯���ĸ���
%--------------------------------------------------------------------------

    [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,N,M); 

    save_obj = [];
    save_can_appear_items_num = zeros(max_evaluations,2); 
    save_div = [];
    
    %% Optimization
    global eval;
    while eval <= max_evaluations        

        MatingPool = TournamentSelection(2,N,FrontNo,-CrowdDis);
        Offspring = GA2(Population(MatingPool,:), proC, M);
        
        for i = 1:N
            Offspring(i,D+1:D+M) = object_fun2(Offspring(i,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU); 
        end        
     
        [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population;Offspring],N,M);
        %------------------------------------------  
        [~, last_generation_F1_index] = find(FrontNo == 1);    
        now_F1_indivs = Population(last_generation_F1_index,:);
     
        %------- Ϊ�˼���HV ------
        temp1 = zeros(size(now_F1_indivs,1),1) + eval;
        temp2 = [now_F1_indivs(:,(D+1):(D+M)),temp1];   
        temp3 = diversity_cal(D+2,50,Population);
        save_obj = [save_obj;temp2]; 
        save_div = [save_div;temp3,eval];
        %-------------------------
    end
end