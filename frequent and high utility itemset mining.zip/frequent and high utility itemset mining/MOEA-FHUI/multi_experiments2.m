function f = multi_experiments2(dataset)

%dataset = 'USCensus10'; 
%dataset = 'foodmart';
%------------------------------------------------
DATA = importdata(['..\dataset\',dataset,'_left_1or0.txt']); 
Wght = importdata(['..\dataset\',dataset,'_right.txt']);  

PW = sum(diag(DATA'*Wght)); 
    
N = 50; % Population size
max_evaluations = 200*N; % maximum number of evaluations   
D = size(DATA,2); 
proC = 1;
proM = 1/D;

problems = 'mySU'; 
M = 2;   % number of objectives


%------------------------------------------------------------------------
times = 30;

A_HVs = zeros(times,1);
save_objs = []; 

%------------------------------------------------
    % ����ÿ��item��support
    item_support = sum(DATA);
    maxItemSup = max(item_support);
    % ����ÿ��item��TWUֵ
    item_TWU = zeros(1,D);
    for j = 1:D
        sum_TWU = 0;
        for i = 1:size(DATA,1)
            if DATA(i,j) == 1
                sum_TWU = sum_TWU + sum(Wght(i,:));
            end
        end
        item_TWU(1,j) = sum_TWU;
    end
    maxItemTWU = max(item_TWU);
%------------------------------------------------
global eval;
for k = 1:times
    fprintf('%d start \n',k);
    eval = 0;
    Population = myInitPop6(DATA,Wght,PW,N); % 18�� (��һ������)trans+meta�ĳ�ʼ������
    %fprintf('%d init  \n',k);
    for i=1:N
        Population(i,D+1:D+M) = object_fun2(Population(i,1:D),DATA,Wght,problems,D,maxItemSup,maxItemTWU);        
    end
    %fprintf('%d after init  \n',k);
    [Population,save_obj,save_can_appear_items_num,save_div] = NSGAII(maxItemSup,maxItemTWU,max_evaluations,Population, N, D, M, DATA,Wght,PW,problems,proC, proM);
    fprintf('%d save  \n',k);
    save(['.\Result\Objs\',dataset,'\',num2str(k,'%01d')], 'save_obj');
    save(['.\Result\Divs\',dataset,'\',num2str(k,'%01d')], 'save_div');
    
    PopObj = Population(:,D+1:D+M);
    NonDominated = NDSort(PopObj,1) == 1;
    fmax_use = 1; % 
    [Score,~] = HV(PopObj(NonDominated,:),fmax_use);
    A_HVs(k,1) = Score;   
    fprintf('%d save two  \n',k);
    save(['.\Result\HVs\',dataset,'\',num2str(k,'%01d')], 'Score');
    fprintf('%d \n',k);
end

fprintf('%d �ζ���ʵ���ƽ��HV = %f \n', times,mean(A_HVs));
end