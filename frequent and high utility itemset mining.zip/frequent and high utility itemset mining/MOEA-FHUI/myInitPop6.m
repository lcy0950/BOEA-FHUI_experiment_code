function PopDec = myInitPop6(DATA,Wght,PW,input)
% 18�� A multi-objective evolutionary approach for mining frequent and high utility itemsets

Popnum = input;
half_Popnum = round(Popnum/2); 

I_num=size(DATA,2);

meta_choose_percents=zeros(1,I_num);% �������meta��ѡ�еĸ���

%fprintf('init 1  \n');
for i1=1:I_num
	D=sum(DATA);
	sup=D(1,i1)/size(DATA,1);
	meta_choose_percents(1,i1)=sup;	
end

%fprintf('init 2  \n');
sum_all_sup=sum(meta_choose_percents);
for ii1=1:I_num
    flg=meta_choose_percents(1,ii1);
    meta_choose_percents(1,ii1)=flg/sum_all_sup;
end



%-------------��������trans-pattern��utility-----------------------
%fprintf('init 3  \n');
trans_choose_percents=zeros(1,size(DATA,1));% �������trans��ѡ�еĸ���
fprintf('size(DATA,1) is %d \n',size(DATA,1));
for i2=1:size(DATA,1)
    %fprintf('%d init 3 1 \n',i2);
	trans_p = DATA(i2,:);
	newpoint=trans_p;
	%�����trans_pattern��utilityֵ
	a=size(DATA,2);
    %fprintf('%d init 3 2 \n',i2);
    m=0;
    record=find(newpoint(1,1:a)==1);
    B1=DATA(:,record); 
    C1=Wght(:,record);
    A1=sum(B1(:,1:length(record)),2); 
    n=find(A1==length(record));
    B2=B1(n,:); 
    C2=C1(n,:);
    m=sum(diag(B2'*C2));
    %fprintf('%d init 3 3 \n',i2);
    utility=m/PW;
	trans_choose_percents(1,i2)=utility;
end
%-------------------------------------------------------------------------------

if I_num < half_Popnum 
  fprintf('error');
else  
  %fprintf('init 4  \n');  
    %--------- ���̶�ѡ��(�зŻ�) -----------
    meta_patterns=[];
    trans_patterns=[]; 
    
    sum_meta_choose_percents = sum(meta_choose_percents);
    sum_trans_choose_percents = sum(trans_choose_percents);
    
    for i = 1 : half_Popnum
        rouletteWheelPosition = rand * sum_meta_choose_percents;
        spinWheel = 0;
        for k1 = 1 : I_num
            spinWheel = spinWheel + meta_choose_percents(1,k1);
            if spinWheel >= rouletteWheelPosition
                meta_pattern = zeros(1,I_num);
                meta_pattern(1,k1) = 1;
                meta_patterns = [meta_patterns;meta_pattern];
                break;
            end
        end
    end
    
%fprintf('init 5  \n');    
row_sum=size(DATA,1);
for i = size(meta_patterns,1)+1 : Popnum
    rouletteWheelPosition = rand * sum_trans_choose_percents;
     spinWheel = 0;
     for k1 = 1 : row_sum
        spinWheel = spinWheel + trans_choose_percents(1,k1);
        if spinWheel >= rouletteWheelPosition
            trans_pattern = DATA(k1,:);
            trans_patterns = [trans_patterns;trans_pattern];
            break;
        end
    end
end
%fprintf('init 6  \n');
    
    %--------------------
    
    
%    
%     q_sup=zeros(1,I_num);
%     row_sum=size(DATA,1);
%     q_uti=zeros(1,row_sum);
    
%     meta_patterns=[];
%     while size(meta_patterns,1) < half_Popnum
%         for k1=1:I_num
%             q_sup(1,k1) = sum(meta_choose_percents(1,1:k1));
%             r1 = rand;
%             if r1 <= q_sup(1,k1) %2.��һ���ĸ���ѡ��meta_pattern
%                 meta_pattern = zeros(1,I_num);
%                 meta_pattern(1,k1) = 1;
%                 meta_patterns = [meta_patterns;meta_pattern];
%                 %meta_patterns = unique(meta_patterns,'rows');
%             end
%         end
%     end
%     meta_patterns=meta_patterns(1:half_Popnum,:);
% %     meta_patterns=unique(meta_patterns,'row');
%     %----------
%     trans_patterns=[];   
%     while size(trans_patterns,1)<half_Popnum
%         for k2=1:row_sum
%             q_uti(1,k2)=sum(trans_choose_percents(1,1:k2)); 
%             r2=rand;
%             if r2<=q_uti(1,k2)
%                 trans_pattern=DATA(k2,:);
%                 trans_patterns=[trans_patterns;trans_pattern];
%                 %trans_patterns=unique(trans_patterns,'rows');
%             end
%         end    
%     end
%     trans_patterns=trans_patterns(1:half_Popnum,:);
% %     trans_patterns=unique(trans_patterns,'row');

   
    
   
  %---------------------------------------------
  PopDec=[meta_patterns;trans_patterns];

end


