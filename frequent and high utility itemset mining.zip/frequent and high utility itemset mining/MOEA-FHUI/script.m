%multi_experiments2('mushroom')
%multi_experiments2('chess')
%multi_experiments2('connect')
%multi_experiments2('accident10')
%multi_experiments2('pumsb')
%multi_experiments2('uscensus10')
multi_experiments2('pamap10')


